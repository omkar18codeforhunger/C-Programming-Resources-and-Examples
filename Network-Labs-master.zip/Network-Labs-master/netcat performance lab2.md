
## Network Labs 2


In this lab you will be making a chat session using NetCat.

![Untitled](https://user-images.githubusercontent.com/47218652/60914213-b0de0580-a24e-11e9-8dff-9c7c665b38c1.png)
